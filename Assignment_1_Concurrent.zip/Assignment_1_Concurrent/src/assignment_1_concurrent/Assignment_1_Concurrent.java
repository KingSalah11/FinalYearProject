/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_1_concurrent;

import java.util.concurrent.Semaphore;

/**
 *
 * @author B00668497
 */
public class Assignment_1_Concurrent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Threads to Queue have been commanded to start");
        System.out.println("Supporters get into the Correct Queue");
        
        Taxi taxiSeats = new Taxi();

        Semaphore empty = new Semaphore (1);
        Semaphore full  = new Semaphore (0);
        Activity activity = new Activity();
        Que taxiService = new Que (empty, full, taxiSeats, activity);
        SupportersInTaxi supporters = new SupportersInTaxi (empty, full, taxiSeats, activity);
        
        //start the processes
        taxiService.start();
        supporters.start();
     	

        
    }
    
}

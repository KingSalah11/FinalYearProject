package assignment_1_concurrent;

import java.util.concurrent.Semaphore;

/**
 *
 * @author B00668497
 */
/* Supporters.java */
class SupportersInTaxi extends Thread {
//below are variables and constructors
    private Semaphore pempty;
    private Semaphore pfull;
    private Taxi taxiSeats;
    private Activity activity;

    public SupportersInTaxi(Semaphore empty, Semaphore full, Taxi seats, Activity activity) {
        pempty = empty;
        pfull = full;
        taxiSeats = seats;
        this.activity = activity;
    } // end constructor

    public void run() {
        /*  Trying to get Supporter out of taxi */
        for (int round = 1; round <= 6; round++) {         
            try {
               
                pfull.acquire(); // // Wait for taxi to be not empty
         
                
            } catch (InterruptedException ie) {
                System.out.println("Taxi Interrupted");
            }
           
                activity.removeAllActivities();
                
                CDS.idleQuietly(100);
            System.out.println("Taxi is Empty");   
            System.out.println("Taxi Drives Back to City Center");
            pempty.release();
                 
        }
        System.out.println("Journey Has Finished");
    }
} // end 

package assignment_1_concurrent;

/* Taxi.java */
class Taxi {
	// Taxi Capacity of size 4 with Supporter number values in locations (0..0)
	final int SIZE = 4;

	int[] supporters = new int[SIZE];
	int putPtr = 0;
	int getPtr = 0;

	public void putSupporter(int supporterNum) {
		supporters[putPtr] = supporterNum;
		putPtr = (putPtr + 1) % SIZE;
	} // end putSupporter

	public int getSupporter() {
		int value = supporters[getPtr];
		getPtr = (getPtr + 1) % SIZE;
		return value;
	} // end getSupporter

} // end Taxi


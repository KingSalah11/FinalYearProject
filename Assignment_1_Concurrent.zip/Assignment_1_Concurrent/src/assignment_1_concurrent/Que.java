package assignment_1_concurrent;

/**
 *
 * @author B00668497
 */
import java.util.List;
import java.util.Random;
import java.util.concurrent.*;

class Que extends Thread {
//below are variables and constructors
    private Semaphore pempty;
    private Semaphore pfull;
    private Taxi taxiSeats;
    private Activity activity;

    public Que(Semaphore empty, Semaphore full, Taxi seats, Activity activity) {
        pempty = empty;
        pfull = full;
        taxiSeats = seats;
        this.activity = activity;
    }

    public void run() {
        for (int i = 0; i < 6; i++) { //how many trips the taxi needs to take
            /* Trying to put a supporter into the taxi  */
            
            try {
                
                pempty.acquire(); // // Wait for taxi to be not full
             
                System.out.println("");
                System.out.println("Supporters await to be signaled");
                System.out.println("Taxi Signals the Supporters in the Queue");
                System.out.println("Taxi Awaits to be Full");
                System.out.println("");
            } catch (InterruptedException ie) {
                System.out.println("Taxi Interrupted");
            } //how many passengers allowed in taxi
            for (int passenger = 1; passenger <= 4; passenger++) {
                System.out.println("passenger = " + passenger);
                int supporterNum = (4 * i) + passenger;
               
                String supporterString = "";

                if (passenger == 4) {
                    List<String> activities = activity.getActivities();
                    int VAR = 0;
                    for (int n = 0; n < activities.size(); n++) {
                        if (activities.get(n).split(" ")[0].equals(SupporterType.LiverpoolFan.toString())) {
                            VAR++;
                        }
                    }
                    switch (VAR) {  //switch statement to add supporters
                        case 3:
                        case 1:
                            supporterString = SupporterType.LiverpoolFan.toString() + " " + supporterNum;
                            activity.addActivity(supporterString);
                            break;
                        case 2:
                        case 0:
                            supporterString = SupporterType.ManU.toString() + " " + supporterNum;
                            activity.addActivity(supporterString);
                            break;
                        default:
                            System.out.println("Taxi already full");
                            break;
                    }
                } else { //to grab a random supporter from queue
                    Random r = new Random();
                    int num = r.nextInt();
                    if (num >= 0) {
                        supporterString = SupporterType.LiverpoolFan.toString() + " " + supporterNum;
                        activity.addActivity(supporterString);
                    } else {
                        supporterString = SupporterType.ManU.toString() + " " + supporterNum;
                        activity.addActivity(supporterString);
                    }
                        
                }
                CDS.idleQuietly(100);
                CDS.idleQuietly(200);
            } // end for loop
            System.out.println("Sorry Taxi is Full");
            System.out.println("Supporter Signals Taxi to Drive to the Football Match");
            System.out.println("Taxi Drives to the Destination");
            System.out.println("Taxi Arrived at the Football Match" + "\n" + "Awaits Supporters to Leave");
            System.out.println("");
            pfull.release(); // Signal that a Taxi has arrived
        }
        
        System.out.println("Last Trip");
        System.out.println("Taxi Driver Finished taking Fans to Match");
    } // end run
} // end of Taxi Service


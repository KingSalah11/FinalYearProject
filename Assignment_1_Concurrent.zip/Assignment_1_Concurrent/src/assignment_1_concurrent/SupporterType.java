package assignment_1_concurrent;

//This is where the type of Supporters are kept
public enum SupporterType {

    LiverpoolFan,
    ManU;
     
}
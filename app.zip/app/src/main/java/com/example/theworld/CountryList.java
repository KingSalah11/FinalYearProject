package com.example.theworld;

import android.app.Activity;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.w3c.dom.Text;

import java.util.List;

public class CountryList extends ArrayAdapter<Country> {

    private Activity context;
    private List<Country> countryList;

    public CountryList(Activity context, List<Country> countryList){
        super(context, R.layout.list_layout, countryList);
        this.context = context;
        this.countryList = countryList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.list_layout, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewContinent = (TextView) listViewItem.findViewById(R.id.textViewContinent);

        Country country = countryList.get(position);

        textViewName.setText(country.getCountryName());
        textViewContinent.setText(country.getCountryContinent());

        return listViewItem;
    }
}

package com.example.theworld;

public class Country {

    String countryId;
    String countryName;
    String countryContinent;

    public Country(){

    }

    public Country(String countryId, String countryName, String countryContinent) {
        this.countryId = countryId;
        this.countryName = countryName;
        this.countryContinent = countryContinent;
    }

    public String getCountryId() {
        return countryId;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getCountryContinent() {
        return countryContinent;
    }
}

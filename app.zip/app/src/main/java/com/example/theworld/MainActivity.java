package com.example.theworld;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText editTextName;
    Button buttonAdd;
    Spinner spinnerContinents;

    DatabaseReference databaseCountries;

    ListView listViewCountries;

    List<Country> countryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseCountries = FirebaseDatabase.getInstance().getReference("countries");

        editTextName = (EditText) findViewById(R.id.editTextName);
        buttonAdd = (Button) findViewById(R.id.buttonAddCountry);
        spinnerContinents = (Spinner) findViewById(R.id.spinnerContinents);

        listViewCountries = (ListView) findViewById(R.id.listViewCountries);

        countryList = new ArrayList<>();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCountry();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseCountries.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                countryList.clear();

                for (DataSnapshot countrySnapshot: dataSnapshot.getChildren()){
                    Country country = countrySnapshot.getValue(Country.class);

                    countryList.add(country);
                }

                CountryList adapter = new CountryList(MainActivity.this, countryList);
                listViewCountries.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void addCountry(){
        String name = editTextName.getText().toString().trim();
        String continent = spinnerContinents.getSelectedItem().toString();

        if(!TextUtils.isEmpty(name)){

           String id = databaseCountries.push().getKey();

           Country country = new Country(id, name, continent);

           databaseCountries.child(id).setValue(country);

           Toast.makeText(this, "Country Added", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "you should enter name", Toast.LENGTH_LONG).show();
        }

    }
}

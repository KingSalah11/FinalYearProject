package com.code.tourism.model.towns

data class Coordinate(
    val globe: String,
    val lat: Double,
    val lon: Double,
    val primary: String
)
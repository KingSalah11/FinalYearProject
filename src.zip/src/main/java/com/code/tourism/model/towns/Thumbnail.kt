package com.code.tourism.model.towns

data class Thumbnail(
    val height: Int,
    val source: String,
    val width: Int
)
package com.code.tourism.model.towns

data class TownModel(
    val batchcomplete: String,
    val query: Query
)
package com.code.tourism.model.towns

data class Pages(
    val pageData: X98255
)
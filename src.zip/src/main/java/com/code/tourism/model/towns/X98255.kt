package com.code.tourism.model.towns

data class X98255(
    val canonicalurl: String,
    val contentmodel: String,
    val coordinates: List<Coordinate>,
    val editurl: String,
    val extract: String,
    val fullurl: String,
    val lastrevid: Int,
    val length: Int,
    val ns: Int,
    val pageid: Int,
    val pageimage: String,
    val pagelanguage: String,
    val pagelanguagedir: String,
    val pagelanguagehtmlcode: String,
    val pageprops: Pageprops,
    val thumbnail: Thumbnail,
    val title: String,
    val touched: String
)
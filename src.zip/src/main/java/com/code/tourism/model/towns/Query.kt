package com.code.tourism.model.towns

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Query(
    @SerializedName("pages")
    @Expose
    val result:Map<String, X98255>
)
package com.code.tourism.model.towns

data class Pageprops(
    val page_image_free: String,
    val wikibase_item: String
)
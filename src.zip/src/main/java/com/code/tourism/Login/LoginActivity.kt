package com.code.tourism.Login

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.code.tourism.BaseActivity
import com.code.tourism.MainActivity
import com.code.tourism.R
import com.code.tourism.room.User
import com.code.tourism.signup.SignUpActivity
import com.code.tourism.utils.Utils
import com.code.tourism.utils.applySchedulers
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        try {
            supportActionBar?.hide()
        } catch (e: Throwable) {
            e.stackTrace
        }

    }

    fun onLoginClick(view: View) {
        if (txtEmailAddress.text.toString().length == 0) {
            showMessage("Please enter email")
            return
        }
        if (!txtEmailAddress.text.toString().isEmailValid()) {
            showMessage("Please enter valid email address")
            return
        }
        if (txtPassword.text.toString().length == 0) {
            showMessage("Please enter password")
            return
        }
        getUser(txtEmailAddress.text.toString(),txtPassword.text.toString());
    }



    private fun getUser(email:String,password:String) {
        getUserDao().getUser(email,password)
            .applySchedulers()
            .compose(applyProgressSingle())
            .subscribe({
                Toast.makeText(this,"Login Successful", Toast.LENGTH_SHORT).show()
                moveTODashBoard(it)
            },{
                Log.e("Error = ${it.message}","")
                Toast.makeText(this,"User not existed", Toast.LENGTH_SHORT).show()
            })

    }

    private fun moveTODashBoard(validUser:User){
        val intent = Intent(this@LoginActivity, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        val bundle = Bundle()
        bundle.putParcelable("user", validUser)
        intent.putExtras(bundle)
        Utils.saveUserObject(this, "user", validUser)
        startActivity(intent)
        finish()

    }

    fun onSignUpClick(view: View) {
        val intent = Intent(this@LoginActivity, SignUpActivity::class.java)
        startActivity(intent)
    }
}

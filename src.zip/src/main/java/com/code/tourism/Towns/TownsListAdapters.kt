package com.code.tourism.Towns

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.code.tourism.R

import com.code.tourism.interfaces.IInterfaceTownItemListener

import com.code.tourism.room.TownCustomModel
import kotlinx.android.synthetic.main.item_layout_town.view.*

import com.ms.square.android.expandabletextview.ExpandableTextView


class TownsListAdapters(val context: Context, var townList: ArrayList<TownCustomModel>) :
    RecyclerView.Adapter<TownsListAdapters.TownViewHolder>() {

    var listener: IInterfaceTownItemListener? = null

    fun updateTown(townsModel: TownCustomModel) {
        townList.add(townsModel)
        notifyDataSetChanged()
    }

    fun updateTowns(townsModel: List<TownCustomModel>) {
        townList.clear()
        townList.addAll(townsModel)
        notifyDataSetChanged()
    }

    fun setTownsListener(listener: IInterfaceTownItemListener) {
        this.listener = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = TownViewHolder(
        LayoutInflater.from(parent.context).inflate(
            com.code.tourism.R.layout.item_layout_town,
            parent,
            false
        )
    )

    override fun getItemCount() = townList.size

    override fun onBindViewHolder(holder: TownViewHolder, position: Int) {
        holder.bind(townList[position])
        holder.container.setOnClickListener {
            if (listener != null) {
                listener?.onTownItemClicked(townList[position])
            }
        }

        if (townList[position].thumbnail != null) {
            Glide.with(context)
                .load(townList[position].thumbnail)
                .apply(RequestOptions.circleCropTransform())
                .placeholder(com.code.tourism.R.drawable.town)
                .into(holder.townImage)
        }

    }

    class TownViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val title = view.town_title
        //private var description: ReadMoreTextView = view.text_view_show_more
        val townImage = view.townImage
        val container: RelativeLayout = view.townContainer
        var expTv1 = view.expandableTextView
        var show = view.buttonShow

        fun bind(model: TownCustomModel) {
            title.text = model.townTitle
            expTv1.text = model.description

            show.setOnClickListener {
                if (expTv1.isExpanded()) {
                    expTv1.collapse();
                    show.setImageResource(R.drawable.upload)
                }
                else {
                    expTv1.expand();
                    show.setImageResource(R.drawable.download)
                }
            }


        }
    }
}
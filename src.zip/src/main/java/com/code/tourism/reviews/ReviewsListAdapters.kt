package com.code.tourism.reviews

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.code.tourism.R
import com.code.tourism.room.Review
import kotlinx.android.synthetic.main.item_layout_review.view.*


class ReviewsListAdapters(val context: Context, var reviewsList: ArrayList<Review>) :
    RecyclerView.Adapter<ReviewsListAdapters.TownViewHolder>() {


    fun updateTown(review: Review) {
        reviewsList.add(0, review)
        //notifyDataSetChanged()
        notifyItemInserted(0)
    }

    fun updateTowns(list: List<Review>) {
        reviewsList.clear()
        reviewsList.addAll(list)
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = TownViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_layout_review, parent, false)
    )

    override fun getItemCount() = reviewsList.size

    override fun onBindViewHolder(holder: TownViewHolder, position: Int) {
        holder.bind(reviewsList[position])

    }

    class TownViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val textViewReview = view.review_value
        private var description = view.review_date
        private var userName = view.user_value
        fun bind(model: Review) {
            textViewReview.text = model.review
            description.text = model.date
            userName.text =model.userName
        }
    }
}
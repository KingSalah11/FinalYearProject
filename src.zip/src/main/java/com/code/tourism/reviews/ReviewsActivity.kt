package com.code.tourism.reviews

import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.code.tourism.BaseActivity
import com.code.tourism.MainActivity
import com.code.tourism.R
import com.code.tourism.room.Review
import com.code.tourism.utils.applySchedulers
import com.codeinside.studynteach.SimpleDividerItemDecoration
import kotlinx.android.synthetic.main.activity_main.rv_list
import kotlinx.android.synthetic.main.activity_reviews.*
import kotlinx.android.synthetic.main.item_layout_town.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class ReviewsActivity : BaseActivity() {


    lateinit var reviewsListAdapters: ReviewsListAdapters
    lateinit var reviewsList: ArrayList<Review>
    lateinit var reviewsListFiltered: ArrayList<Review>

    var townId: Int = 0
    var title: String? = null
    var extract: String? = null
    var image: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.code.tourism.R.layout.activity_reviews)

        if (supportActionBar != null) {
            supportActionBar?.setTitle("Reviews")
            supportActionBar?.setDefaultDisplayHomeAsUpEnabled(true)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        if (intent != null) {
            townId = intent.extras?.get("townId") as Int
            title = intent.extras?.get("title") as String
            extract = intent.extras?.get("extract") as String
            image = intent.extras?.get("image") as String

            if (!image.equals("")) {
                Glide.with(this)
                    .load(image)
                    .apply(RequestOptions.circleCropTransform())
                    .placeholder(R.drawable.town)
                    .into(townImage)
            }

            town_title.text = title
            expandableTextView.text = extract

            buttonShow.setOnClickListener {
                if (expandableTextView.isExpanded()) {
                    expandableTextView.collapse();
                    buttonShow.setImageResource(R.drawable.upload)
                }
                else {
                    expandableTextView.expand();
                    buttonShow.setImageResource(R.drawable.download)
                }
            }

        }
        reviewsList = ArrayList<Review>()
        reviewsListFiltered = ArrayList<Review>()
        setList(reviewsList)
        getTownInformation()

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setList(list: ArrayList<Review>) {
        rv_list.layoutManager = LinearLayoutManager(this)
        rv_list.addItemDecoration(SimpleDividerItemDecoration(this));

        try {
            reviewsListAdapters = ReviewsListAdapters(this, list)
            rv_list.adapter = reviewsListAdapters

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun getTownInformation() {
        showLoading(true)
        getReviewDao().getAllReviewsUsingTownId(townId)
            .applySchedulers()
            .subscribe({
                reviewsListAdapters.updateTowns(it)
                reviewsListAdapters.notifyDataSetChanged()
                showLoading(false)
            },{
                showLoading(false)
                Toast.makeText(this, "Error fetching reviews", Toast.LENGTH_SHORT).show()
            })
    }

    override fun onResume() {
        super.onResume()
        baseContext = this
    }

    fun onReviewButtonClicked(view: View) {
        showLoading(true)
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime())
        var review = Review(
            review = reviewEditText.text.toString(),
            date = date,
            townsId = townId,
            userId = MainActivity.user.userId,
            userName = MainActivity.user.userName

        )

        getReviewDao().insert(review)
            .applySchedulers()
            .subscribe({
                Toast.makeText(this, "Review Added Successfully", Toast.LENGTH_SHORT).show()
                showLoading(false)
            }, {
                Log.e("Error = ${it.message}", "")
                showLoading(false)
                Toast.makeText(this, "Error adding review", Toast.LENGTH_SHORT).show()
            })
    }
}

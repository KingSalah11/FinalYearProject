package com.code.tourism.signup

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import com.code.tourism.BaseActivity
import com.code.tourism.MainActivity
import com.code.tourism.R
import com.code.tourism.room.User
import com.code.tourism.utils.Utils
import com.code.tourism.utils.applySchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_sign_up.*

data class ValidUser(var email: String, var password: String)
class SignUpActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        try {
            supportActionBar?.hide()
        } catch (e: Throwable) {
            e.stackTrace
        }
    }

    fun onSignUpClick(view: View) {


        if (txtUserName.text.toString().length == 0) {
            showMessage("Please enter username")
            return
        }

        if (txtEmailAddress.text.toString().length == 0) {
            showMessage("Please enter email")
            return
        }

        if (!txtEmailAddress.text.toString().isEmailValid()) {
            showMessage("Please enter valid email address")
            return
        }

        if (txtPassword.text.toString().length == 0) {
            showMessage("Please enter password")
            return
        }


        if (cb_isAdmin.isChecked) {
            var user = User(
                userName = txtUserName.text.toString(),
                email = txtEmailAddress.text.toString(),
                password = txtPassword.text.toString(),
                isAdmin = true

            )
            getUser(user)
        } else {

            var user = User(
                userName = txtUserName.text.toString(),
                email = txtEmailAddress.text.toString(),
                password = txtPassword.text.toString(),
                isAdmin = false

            )

            getUser(user)

        }




    }


    private fun getUser(validUser: User) {



        getUserDao().checkUserExist(validUser.email)
            .flatMap {
                if (it > 0) {
                    io.reactivex.Single.just(-1)
                } else {
                    insertUser(validUser).subscribeOn(Schedulers.io())
                }
            }.applySchedulers()
            .compose(applyProgressSingle())
            .subscribe({
                if (it == -1) {
                    Toast.makeText(this, "User Already existed", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "User Created", Toast.LENGTH_SHORT).show()
                    moveTODashBoard(validUser)
                }
            }, {
                Log.e("Error = ${it.message}", "")
                Toast.makeText(this, "Error creating User", Toast.LENGTH_SHORT).show()
            })
    }

    private fun insertUser(validUser: User): io.reactivex.Single<Long> {
        return getUserDao().insert(validUser)
    }

    private fun moveTODashBoard(validUser: User) {
        val intent = Intent(this@SignUpActivity, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        val bundle = Bundle()
        bundle.putParcelable("user", validUser)
        intent.putExtras(bundle)
        Utils.saveUserObject(this, "user", validUser)
        startActivity(intent)
        finish()

    }
}

package com.code.tourism.interfaces

import com.code.tourism.model.towns.TownModel
import com.code.tourism.room.TownCustomModel

interface IInterfaceTownItemListener {
    fun onTownItemClicked(townsModel: TownCustomModel)
}
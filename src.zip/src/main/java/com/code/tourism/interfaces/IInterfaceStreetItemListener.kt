package com.code.tourism.interfaces

import com.code.tourism.room.Street

interface IInterfaceStreetItemListener {
    fun onStreetItemClickedListener(street:Street)
}
package com.code.tourism.room

import androidx.room.*


@Dao
interface ReviewDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(review: Review):io.reactivex.Single<Long>

    @Query("SELECT * FROM reviews_table where townsId =:twonId")
    fun getAllReviewsUsingTownId(twonId:Int): io.reactivex.Observable<List<Review>>

}
package com.code.tourism.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import io.reactivex.Observable
import io.reactivex.Single


@Dao
interface RentDao {

    @Insert
    fun insert(streetRent: StreetRent): Single<Long>

    @Query("SELECT * FROM streets_rent_table")
    fun getAllRentInformation(): io.reactivex.Single<List<StreetRent>>


}
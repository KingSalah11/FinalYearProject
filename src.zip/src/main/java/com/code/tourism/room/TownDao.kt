package com.code.tourism.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import io.reactivex.Observable
import io.reactivex.Single


@Dao
interface TownDao {

    @Insert
    fun insert(town: Town): Single<Long>

    @Query("SELECT * FROM towns_table")
    fun getAllTownInformation(): io.reactivex.Single<List<Town>>




}
package com.code.tourism.room

import androidx.room.*


@Dao
interface StreetDao {

    @Insert
    fun insert(street: Street):io.reactivex.Single<Long>

    @Query("SELECT * FROM street_table")
    fun getAllStreet(): io.reactivex.Single<List<Street>>

    @Update
    fun update(street: Street):io.reactivex.Single<Int>

    @Delete
    fun delete(street: Street):io.reactivex.Single<Int>

}
package com.code.tourism.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(entities = arrayOf(User::class,Town::class,Review::class,Street::class,StreetRent::class), version = 1, exportSchema = false)
abstract class DemographicDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun reviewDao(): ReviewDao
    abstract fun townDao(): TownDao
    abstract fun streetDao(): StreetDao
    abstract fun streetRentDao(): RentDao

    companion object {
        private var INSTANCE: DemographicDatabase? = null
        fun getDatabase(context: Context): DemographicDatabase? {
            if (INSTANCE == null) {
                synchronized(DemographicDatabase::class) {
                    INSTANCE = Room.databaseBuilder(
                        context.getApplicationContext(),
                        DemographicDatabase::class.java, "demographic_database.db"
                    ).build()
                }
            }
            return INSTANCE
        }
    }
}
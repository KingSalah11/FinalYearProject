package com.code.tourism.room

import android.os.Parcel
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey


@Entity(tableName = "user_table")
data class User(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "userId") val userId: Int? = null,
    @ColumnInfo(name = "userName") val userName: String?,
    @ColumnInfo(name = "email") val email: String?,
    @ColumnInfo(name = "password") val password: String?,
    @ColumnInfo(name = "isAdmin") val isAdmin: Boolean?
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Boolean::class.java.classLoader) as? Boolean
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(userId)
        parcel.writeString(userName)
        parcel.writeString(email)
        parcel.writeString(password)
        parcel.writeValue(isAdmin)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<User> {
        override fun createFromParcel(parcel: Parcel): User {
            return User(parcel)
        }

        override fun newArray(size: Int): Array<User?> {
            return arrayOfNulls(size)
        }
    }
}


@Entity(tableName = "towns_table")
data class Town(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "townId") val townId: Int? = null,
    @ColumnInfo(name = "townTitle") val townTitle: String?,
    @ColumnInfo(name = "description") val description: String?,
    @ColumnInfo(name = "thumbnail") val thumbnail: String?,
    @ColumnInfo(name = "lat") val lat: Double?,
    @ColumnInfo(name = "lon") val lon: Double?

) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Double::class.java.classLoader) as? Double,
        parcel.readValue(Double::class.java.classLoader) as? Double
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(townId)
        parcel.writeString(townTitle)
        parcel.writeString(description)
        parcel.writeString(thumbnail)
        parcel.writeValue(lat)
        parcel.writeValue(lon)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Town> {
        override fun createFromParcel(parcel: Parcel): Town {
            return Town(parcel)
        }

        override fun newArray(size: Int): Array<Town?> {
            return arrayOfNulls(size)
        }
    }
}


//@Entity(
//    tableName = "reviews_table",
//    foreignKeys = [
//        ForeignKey(
//            entity = Town::class,
//            parentColumns = ["townId"],
//            childColumns = ["reviewId"],
//            onDelete = ForeignKey.CASCADE
//        )
//    ]
//)
@Entity(tableName = "reviews_table")
data class Review(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "reviewId") val reviewId: Int? = null,
    @ColumnInfo(name = "review") val review: String?,
    @ColumnInfo(name = "date") val date: String?,
    @ColumnInfo(name = "townsId") val townsId: Int? = null,
    @ColumnInfo(name = "userId") val userId: Int? = null,
    @ColumnInfo(name = "userName") val userName: String? = null

) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Int::class.java.classLoader) as? Int
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(reviewId)
        parcel.writeString(review)
        parcel.writeString(date)
        parcel.writeValue(townsId)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Review> {
        override fun createFromParcel(parcel: Parcel): Review {
            return Review(parcel)
        }

        override fun newArray(size: Int): Array<Review?> {
            return arrayOfNulls(size)
        }
    }
}

@Entity(tableName = "street_table")
data class Street(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "streetId") val streetId: Int? = null,
    @ColumnInfo(name = "streetName") var streetName: String?,
    @ColumnInfo(name = "StreetRent") var streetRent: String?,
    @ColumnInfo(name = "streetLane") var streetLane: String?,
    @ColumnInfo(name = "localAuthority") var localAuthority: String?,
    @ColumnInfo(name = "areaType") var areaType: String?,
    @ColumnInfo(name = "postcode") var postcode: String?,
    @ColumnInfo(name = "town") var town: String?,
    @ColumnInfo(name = "UKParliamentaryConstituency") var UKParliamentaryConstituency: String?,
    @ColumnInfo(name = "streetImage") var streetImage: String?

) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readValue(Int::class.java.classLoader) as? Int,
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeValue(streetId)
        parcel.writeString(streetName)
        parcel.writeString(streetRent)
        parcel.writeString(streetLane)
        parcel.writeString(localAuthority)
        parcel.writeString(areaType)
        parcel.writeString(postcode)
        parcel.writeString(town)
        parcel.writeString(UKParliamentaryConstituency)
        parcel.writeString(streetImage)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Street> {
        override fun createFromParcel(parcel: Parcel): Street {
            return Street(parcel)
        }

        override fun newArray(size: Int): Array<Street?> {
            return arrayOfNulls(size)
        }
    }

}

@Entity(tableName = "streets_rent_table")
data class StreetRent(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "streetRentId") val streetRentId: Int? = null,
    @ColumnInfo(name = "streetRent") val streetName: Int?
)

package com.code.tourism.room

data class TownCustomModel(
    val townId: Int,
    val townTitle: String?,
    val description: String?,
    val thumbnail: String?,
    val lat: Double?,
    val lon: Double?
)
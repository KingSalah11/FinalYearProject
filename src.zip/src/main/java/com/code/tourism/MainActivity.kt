package com.code.tourism

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.code.tourism.Login.LoginActivity
import com.code.tourism.Towns.TownsListAdapters
import com.code.tourism.interfaces.IInterfaceTownItemListener
import com.code.tourism.model.towns.TownModel
import com.code.tourism.network.ApiClient
import com.code.tourism.reviews.ReviewsActivity
import com.code.tourism.room.Town
import com.code.tourism.room.TownCustomModel
import com.code.tourism.room.User
import com.code.tourism.streets.StreetsActivity
import com.code.tourism.utils.applySchedulers
import com.codeinside.studynteach.SimpleDividerItemDecoration
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.rxkotlin.subscribeBy
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : BaseActivity(), IInterfaceTownItemListener {

    companion object {
        lateinit var user: User
    }

    override fun onTownItemClicked(townsModel: TownCustomModel) {

        val intent = Intent(this, ReviewsActivity::class.java)
        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        val bundle = Bundle()
        bundle.putString("title", townsModel.townTitle)
        bundle.putString("extract", townsModel.description)
        bundle.putInt("townId", townsModel.townId!!)
        bundle.putString("image", townsModel.thumbnail)

        intent.putExtras(bundle)
        startActivity(intent)
    }


    lateinit var townsListAdapters: TownsListAdapters
    lateinit var townList: ArrayList<TownCustomModel>
    lateinit var townListFiltered: ArrayList<TownCustomModel>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (supportActionBar != null) {
            supportActionBar?.setTitle("Towns")
        }


        if (intent != null) {
            user = intent.extras?.get("user") as User
        }

        townList = ArrayList<TownCustomModel>()
        townListFiltered = ArrayList<TownCustomModel>()
        setList(townList)
        //getTownInformation()
        getAllTownInformationFromDatabase()

    }

    override fun onResume() {
        super.onResume()
        baseContext = this
    }

    private fun setList(list: ArrayList<TownCustomModel>) {
        rv_list.layoutManager = LinearLayoutManager(this)
        rv_list.addItemDecoration(SimpleDividerItemDecoration(this));

        try {
            townsListAdapters = TownsListAdapters(this, list)
            townsListAdapters.setTownsListener(this)
            rv_list.adapter = townsListAdapters

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }


    private fun getAllTownInformationFromDatabase() {
        showLoading(true)
        getTownDao().getAllTownInformation()
            .applySchedulers()
            .subscribe({

                if (it != null && it.size > 0) {
                    for (i in 0 until it.size) {
                        townListFiltered.add(getDatabaseObject(it.get(i)))
                    }
                    townsListAdapters.updateTowns(townListFiltered)
                    townsListAdapters.notifyDataSetChanged()
                    showLoading(false)
                } else {
                    getTownInformation()
                }
            }, {
                showLoading(false)
                Log.e("Error = ${it.message}", "")
                Toast.makeText(this, "Error creating User", Toast.LENGTH_SHORT).show()
            })
    }

    private fun getTownInformation() {

        var townList1: ArrayList<String> = ArrayList();
        townList1.add("Newtownards")
        townList1.add("Belfast")
        townList1.add("Dundonald")
        townList1.add("Bangor")
        townList1.add("Comber")
        townList1.add("Holywood")


        Observable.fromIterable(townList1).flatMap { it ->
            ApiClient.getClient.getTownInformation(titles = it)
        }.applySchedulers()
            .subscribeBy(
                onNext = {

                    var image = ""
                    var lat: Double = -1.0
                    var lon: Double = -1.0
                    if (it.query.result.values.toTypedArray()[0].thumbnail != null) {
                        image = it.query.result.values.toTypedArray()[0].thumbnail.source
                    }

                    if (it.query.result.values.toTypedArray()[0].coordinates != null) {
                        lat = it.query.result.values.toTypedArray()[0].coordinates.get(0).lat
                        lon = it.query.result.values.toTypedArray()[0].coordinates.get(0).lon
                    }
                    var townCustom = TownCustomModel(
                        1,
                        townTitle = it.query.result.values.toTypedArray()[0].title,
                        description = it.query.result.values.toTypedArray()[0].extract,
                        thumbnail = image,
                        lat = lat,
                        lon = lon

                    )
                    townListFiltered.add(townCustom)
                },
                onComplete = {
                    //townsListAdapters.updateTowns(townListFiltered)
                    //townsListAdapters.notifyDataSetChanged()
                    saveTownsInDatabase(townListFiltered)
                },
                onError = {
                    showLoading(false)
                    Log.e("Error = ${it.message}", "")
                    Toast.makeText(this, "Something went while fetching data", Toast.LENGTH_SHORT)
                        .show()
                }

            )

    }


    private fun saveTownsInDatabase(list: ArrayList<TownCustomModel>) {
        Observable.fromIterable(list).flatMap { it ->
            saveObjectInDatabase(it)
        }.applySchedulers()
            .subscribeBy(
                onNext = {
                    var a = ""
                },
                onComplete = {
                    showLoading(false)
                    var b = ""
                    getAllTownInformationFromDatabase()

                },
                onError = {
                    showLoading(false)
                    Log.e("Error = ${it.message}", "")
                    Toast.makeText(this, "Something went while fetching data", Toast.LENGTH_SHORT)
                        .show()
                }

            )

    }


    private fun getDatabaseObject(town: Town): TownCustomModel {
        return TownCustomModel(
            townId = town.townId!!,
            townTitle = town.townTitle,
            description = town.description,
            thumbnail = town.thumbnail,
            lat = town.lat,
            lon = town.lon

        )
    }

    private fun saveObjectInDatabase(townObject: TownCustomModel): Observable<Long> {
        var townDatabase = Town(
            townTitle = townObject.townTitle,
            description = townObject.description,
            thumbnail = townObject.thumbnail,
            lat = townObject.lat,
            lon = townObject.lon

        )
        return getTownDao().insert(townDatabase).toObservable()
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.getItemId()
        if (id == R.id.action_street) {
            startActivity(Intent(this, StreetsActivity::class.java))
            return true
        }

        if (id==R.id.action_logout){
            val intent = Intent(this, LoginActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
            return true

        }
        return super.onOptionsItemSelected(item)
    }

}

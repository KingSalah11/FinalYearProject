package com.code.tourism

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.annotation.StringRes
import com.code.tourism.room.*
import com.google.android.material.snackbar.Snackbar
import com.google.gson.JsonParser
import com.google.gson.annotations.SerializedName
import io.reactivex.*
import kotlinx.coroutines.*
import retrofit2.HttpException
import java.util.regex.Pattern
import kotlin.coroutines.CoroutineContext




data class ApiException(@SerializedName("message") val mMessage: String) : Throwable()

open class BaseActivity : AppCompatActivity(), CoroutineScope {

    private val job: Job = Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Default + job

    private var demographicDatabase: DemographicDatabase? = null

    lateinit var baseContext: BaseActivity

    internal lateinit var containter: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        baseContext = this

        initDatabase()


    }

     fun showLoading(show: Boolean) {
         try {

             containter = findViewById<LinearLayout>(R.id.container)
             if (show) {
                 if (containter != null) {
                     containter.bringToFront()
                     containter.setVisibility(View.VISIBLE)
                 }
             } else {
                 if (containter != null) {
                     containter.setVisibility(View.GONE)
                 }
             }
         }catch (e:Exception){
             e.printStackTrace()
         }
    }

    private fun initDatabase() {
        demographicDatabase = DemographicDatabase.getDatabase(this@BaseActivity)
    }

    fun getUserDao(): UserDao {
        return demographicDatabase?.userDao()!!
    }
    fun getReviewDao(): ReviewDao {
        return demographicDatabase?.reviewDao()!!
    }

    fun getTownDao(): TownDao {
        return demographicDatabase?.townDao()!!
    }

    fun getStreetDao(): StreetDao {
        return demographicDatabase?.streetDao()!!
    }

    fun getStreetRentDao(): RentDao {
        return demographicDatabase?.streetRentDao()!!
    }


    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }

    fun showMessage(message: String) {
        Toast.makeText(this@BaseActivity, message, Toast.LENGTH_SHORT).show()
    }

    fun View.snackBar(@StringRes id: Int) {
        Snackbar.make(this, id, Snackbar.LENGTH_LONG).show()
    }

    fun String.isEmailValid() =
        Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
        ).matcher(this).matches()


    protected fun <T> Single<T>.checkApiErrorSingle(): Single<T> =
        onErrorResumeNext { throwable ->
            parseHttpExceptionSingle(throwable)
        }

    protected fun Completable.checkApiErrorCompletable(): Completable =
        onErrorResumeNext { throwable ->
            parseHttpExceptionCompletable(throwable)
        }

    protected fun <T> Observable<T>.checkApiErrorObservable(): Observable<T> =
        doOnError { throwable ->
            parseHttpExceptionObservable(throwable)
        }

    private fun parseHttpExceptionObservable(throwable: Throwable): Observable<Any> {
        if (throwable !is HttpException) {
            return Observable.error(throwable)
        }
        val error = getError(throwable)
        if (error != null) {
            return Observable.error(ApiException(error))
        }

        return Observable.error(throwable)
    }

    private fun <T> parseHttpExceptionSingle(throwable: Throwable): Single<T> {
        //Timber.e("throwable = $throwable")
        if (throwable is ApiException) {
            return Single.error(throwable)
        }
        if (throwable !is HttpException) {
            return Single.error(throwable)
        }
        val error = getError(throwable)
       // Timber.e("error = $error")
        if (error != null) {
            return Single.error(ApiException(error))
        }

        return Single.error(throwable)
    }

    private fun parseHttpExceptionCompletable(throwable: Throwable): Completable {
        if (throwable !is HttpException) {
            return Completable.error(throwable)
        }
        val error = getError(throwable)
        if (error != null) {
            return Completable.error(ApiException(error))
        }
        return Completable.error(throwable)
    }

    private fun getError(throwable: Throwable): String? {
        val parser = JsonParser()
        val body = parser.parse((throwable as HttpException).response()?.errorBody()?.string()).asJsonObject
//        if (body.has(FIELD_ERRORS)) {
////            val messageBody = body.get(FIELD_ERRORS).asJsonObject
////            return messageBody.get(FIELD_MESSAGE).asString
//            val messageBody = body.get(FIELD_ERRORS).asString
//            return messageBody
//        }
        return null
    }


     fun <T> applyProgressObservable(tag: Any? = null): ObservableTransformer<T, T> =
        ObservableTransformer {
            it.doOnSubscribe { showLoading(true) }.doFinally { showLoading(false) }
        }

     fun applyProgressCompletable(tag: Any? = null): CompletableTransformer =
        CompletableTransformer {
            it.doOnSubscribe {showLoading(true) }.doFinally { showLoading(false) }
        }

     fun <T> applyProgressSingle(tag: Any? = null): SingleTransformer<T, T> =
        SingleTransformer {
            it.doOnSubscribe {showLoading(true) }.doFinally {
                showLoading(false)
            }
        }

//    private fun showDefaultErrors(throwable: Throwable?, tag: Any? = null) {
//        view?.hideProgress(tag)
//        //Timber.e("Throwable === ${throwable}")
//        if (throwable is ApiException) {
//            view?.showMessage(throwable.mMessage)
//        }
//        else if (throwable is Error) {
//            view?.showMessage(throwable.message!!)
//        }
//        else {
//            throwable?.message?.let { view?.showMessage(it) }
//        }
//    }






}

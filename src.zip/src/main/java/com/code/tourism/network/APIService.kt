package com.code.tourism.network

import com.code.tourism.model.towns.TownModel
import io.reactivex.Observable
import retrofit2.http.GET
import retrofit2.http.Query

interface APIService {

    @GET("w/api.php?")
    fun getTownInformation(
        @Query("action") lat: String = "query",
        @Query("titles") titles: String,
        @Query("prop") prop: String = "extracts|info|pageimages|coordinates|pageprops",
        @Query("explaintext") explaintext: String = "",
        @Query("redirects") redirects: String = "",
        @Query("inprop") inprop: String = "url",
        @Query("format") format: String = "json"
    ): Observable<TownModel>


}
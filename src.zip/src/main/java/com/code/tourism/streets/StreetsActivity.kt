package com.code.tourism.streets

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.code.tourism.BaseActivity
import com.code.tourism.MainActivity
import com.code.tourism.R
import com.code.tourism.interfaces.IInterfaceStreetItemListener
import com.code.tourism.reviews.ReviewsActivity
import com.code.tourism.room.Street
import com.code.tourism.utils.applySchedulers
import com.codeinside.studynteach.SimpleDividerItemDecoration
import kotlinx.android.synthetic.main.activity_main.rv_list
import kotlinx.android.synthetic.main.activity_streets.*
import kotlinx.android.synthetic.main.layout_item_add_rent.view.*

class StreetsActivity : BaseActivity(), IInterfaceStreetItemListener {

    override fun onStreetItemClickedListener(street: Street) {

        if (MainActivity.user.isAdmin!!) {
            val intent = Intent(this, StreetInformationActivity::class.java)
            val bundle = Bundle()
            bundle.putParcelable("street", street)
            intent.putExtras(bundle)
            startActivity(intent)
        } else {
            addRent(street)
        }
    }

    private fun addRent(street: Street) {
        val mDialogView = LayoutInflater.from(this).inflate(R.layout.layout_item_add_rent, null)
        val mBuilder = AlertDialog.Builder(this)
            .setView(mDialogView)
            .setTitle("Add Rent")
        val mAlertDialog = mBuilder.show()
        mDialogView.add_button.setOnClickListener {
            val name = mDialogView.rent_price.text.toString().toLowerCase()
            //Add code for saving in the database
            Toast.makeText(this, "Rent added successfully", Toast.LENGTH_SHORT).show()
            mAlertDialog.dismiss()
        }
        mDialogView.cancel_button.setOnClickListener { mAlertDialog.dismiss() }
    }

    lateinit var streetListAdapters: StreetListAdapters
    lateinit var streetList: ArrayList<Street>
    lateinit var streetListFiltered: ArrayList<Street>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_streets)

        if (supportActionBar != null) {
            supportActionBar?.setTitle("Streets")
            supportActionBar?.setDefaultDisplayHomeAsUpEnabled(true)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        if (!MainActivity.user.isAdmin!!) {
            add_street_info.visibility = View.GONE
        }

        streetList = ArrayList<Street>()
        streetListFiltered = ArrayList<Street>()

//        var street = Street(
//            streetName = "Southport",
//            streetRent = "1773",
//            streetLane = "Silverdale Road",
//            localAuthority = "Sefton",
//            areaType = "Urban",
//            postcode = "CH63 5JG",
//            town = "Newtownards",
//            UKParliamentaryConstituency = "Southport"
//
//        )
//
//        streetList.add(street)
        setList(streetList)
    }

    private fun setList(list: ArrayList<Street>) {
        rv_list.layoutManager = LinearLayoutManager(this)
        rv_list.addItemDecoration(SimpleDividerItemDecoration(this));

        try {
            streetListAdapters = StreetListAdapters(this, list)
            streetListAdapters.setTownsListener(this)
            rv_list.adapter = streetListAdapters
            streetListAdapters.notifyDataSetChanged()

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun onResume() {
        super.onResume()
        getStreetsInformationFromDatabase()
    }

    private fun getStreetsInformationFromDatabase(){
        showLoading(true)
        getStreetDao().getAllStreet()
            .applySchedulers()
            .subscribe({
                if (it!=null && it.size>0){
                    streetListAdapters.updateTowns(it)
                }

                showLoading(false)
            },{
                showLoading(false)
                Log.e("Error = ${it.message}", "")
                Toast.makeText(this, "Error creating User", Toast.LENGTH_SHORT).show()
            })

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun onReviewButtonClicked(view: View) {
        val intent = Intent(this, StreetInformationActivity::class.java)
        val bundle = Bundle()
        bundle.putParcelable("street", null)
        intent.putExtras(bundle)
        startActivity(intent)
    }

}

package com.code.tourism.streets

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.bumptech.glide.Glide
import com.code.tourism.BaseActivity
import com.code.tourism.R
import com.code.tourism.room.Street
import com.code.tourism.utils.applySchedulers
import com.github.dhaval2404.imagepicker.ImagePicker
import kotlinx.android.synthetic.main.activity_street_information.*
import java.io.File

class StreetInformationActivity : BaseActivity() {
    var street: Street? = null
    var selectedFilePath:String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_street_information)

        if (supportActionBar != null) {
            supportActionBar?.setTitle("Street Information")
            supportActionBar?.setDefaultDisplayHomeAsUpEnabled(true)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        if (intent != null) {
            street = intent.extras?.getParcelable<Street>("street") as Street?

            if (street != null) {
                add_new_street_info.visibility = View.GONE
                street_name.setText(street?.streetName)
                street_lane.setText(street?.streetLane)
                street_rent.setText(street?.streetRent)
                street_authority.setText(street?.localAuthority)
                street_area_type.setText(street?.areaType)
                street_post_code.setText(street?.postcode)
                street_town.setText(street?.town)
                street_constituency.setText(street?.UKParliamentaryConstituency)
                selectedFilePath = street?.streetImage!!
                showImage(selectedFilePath)

            } else{
                delete_street_info.visibility =View.GONE
                update_street_info.visibility =View.GONE
            }

        }

        street_image.setOnClickListener {
            ImagePicker.with(this)
                .crop()
                .compress(1024)
                .maxResultSize(1080, 1080)
                .start()
        }
    }

    private fun showImage(path:String){
        Glide.with(this@StreetInformationActivity)
            .load(path)
            .circleCrop()
            .placeholder(R.drawable.town)
            .into(street_image)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            //Image Uri will not be null for RESULT_OK
            val fileUri = data?.data

            //You can get File object from intent
            val file: File = ImagePicker.getFile(data)!!
            selectedFilePath = file.path
            showImage(file.path)

            //You can also get File Path from intent
            val filePath:String = ImagePicker.getFilePath(data)!!
        } else if (resultCode == ImagePicker.RESULT_ERROR) {
            Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun onDeleteStreetClicked(view: View) {
        getStreetDao().delete(street!!).applySchedulers()
            .compose(applyProgressSingle())
            .subscribe({
                Toast.makeText(this, "Street deleted successfully", Toast.LENGTH_SHORT).show()
                finish()

            }, {
                Log.e("Error = ${it.message}", "")
                Toast.makeText(this, "Error while deleting street", Toast.LENGTH_SHORT).show()
            })
    }

    fun onUpdateStreetClicked(view: View) {

        street?.streetName = street_name.getText().toString()
        street?.streetLane = street_lane.getText().toString()
        street?.streetRent = street_rent.getText().toString()
        street?.localAuthority = street_authority.getText().toString()
        street?.areaType = street_area_type.getText().toString()
        street?.postcode = street_post_code.getText().toString()
        street?.town = street_town.getText().toString()
        street?.UKParliamentaryConstituency = street_constituency.getText().toString()
        street?.streetImage = selectedFilePath
        getStreetDao().update(street!!).applySchedulers()
            .compose(applyProgressSingle())
            .subscribe({
                Toast.makeText(this, "Street updated successfully", Toast.LENGTH_SHORT).show()
                finish()

            }, {
                Log.e("Error = ${it.message}", "")
                Toast.makeText(this, "Error while updating street", Toast.LENGTH_SHORT).show()
            })

    }

    fun onAddStreetClicked(view: View) {
        var street = Street(
            streetName = street_name.getText().toString(),
            streetRent = street_rent.getText().toString(),
            streetLane = street_lane.getText().toString(),
            localAuthority = street_authority.getText().toString(),
            areaType = street_area_type.getText().toString(),
            postcode = street_post_code.getText().toString(),
            town = street_town.getText().toString(),
            UKParliamentaryConstituency = street_constituency.getText().toString(),
            streetImage = selectedFilePath

        )

        getStreetDao().insert(street!!).applySchedulers()
            .compose(applyProgressSingle())
            .subscribe({
                Toast.makeText(this, "Street added successfully", Toast.LENGTH_SHORT).show()
                finish()

            }, {
                Log.e("Error = ${it.message}", "")
                Toast.makeText(this, "Error while addeding street", Toast.LENGTH_SHORT).show()
            })

    }
}

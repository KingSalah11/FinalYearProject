package com.code.tourism.streets

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.code.tourism.R
import com.code.tourism.interfaces.IInterfaceStreetItemListener
import com.code.tourism.room.Street
import kotlinx.android.synthetic.main.activity_street_information.*
import kotlinx.android.synthetic.main.item_layout_street.view.*
import kotlinx.android.synthetic.main.item_layout_town.view.*


class StreetListAdapters(val context: Context, var townList: ArrayList<Street>) :
    RecyclerView.Adapter<StreetListAdapters.TownViewHolder>() {

    var listener: IInterfaceStreetItemListener? = null

    fun updateTown(townsModel: Street) {
        townList.add(townsModel)
        notifyDataSetChanged()
    }

    fun updateTowns(townsModel: List<Street>) {
        townList.clear()
        townList.addAll(townsModel)
        notifyDataSetChanged()
    }

    fun setTownsListener(listener: IInterfaceStreetItemListener) {
        this.listener = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = TownViewHolder(
        LayoutInflater.from(parent.context).inflate(
            com.code.tourism.R.layout.item_layout_street,
            parent,
            false
        )
    )

    override fun getItemCount() = townList.size

    override fun onBindViewHolder(holder: TownViewHolder, position: Int) {
        holder.bind(townList[position])
        holder.container.setOnClickListener {
            if (listener != null) {
                listener?.onStreetItemClickedListener(townList[position])
            }
        }

        Glide.with(context)
            .load(townList[position].streetImage)
            .circleCrop()
            .placeholder(R.drawable.town)
            .into(holder.streetImage)

    }

    class TownViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val streetName = view.street_value
        private val townName = view.town_value
        private val streetRent = view.rent_value
        private val streetLane = view.street_lane
        private val streetArea = view.street_area
        private val streetCode = view.street_postcode
        var streetImage = view.userImage


        val container: RelativeLayout = view.streetContainer


        fun bind(model: Street) {
            streetName.text = model.streetName
            townName.text = model.town
            streetRent.text = "Rent: "+model.streetRent
            streetLane.text = model.streetLane
            streetArea.text = model.areaType
            streetCode.text = model.postcode




        }
    }
}